package com.assert;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class AssertFunctions 
{

public static Boolean Edit(WebDriver dw)		
{ 	
	     
        boolean result = false;
        if(Edit.fnd_edit(dw).isDisplayed()){
            result = true;
        }
        return result;
}

public static Boolean Ignore(WebDriver dw)		
{ 	
     
    boolean result = false;
    if(Edit.fnd_saveigndw).isDisplayed()){
        result = true;
    }
    return result;
}

public static Boolean Share(WebDriver dw)		//Share Button//
{ 	
     
    boolean result = false;
    if(Edit.clk_ldshare(dw).isDisplayed()){
        result = true;
    }
    return result;
}


public static Boolean Save(WebDriver dw) throws Exception	
{ 	
	 Thread.sleep(2000);
    boolean result = false;
    if(Account.fnd_savebtn(dw).isDisplayed()){
        result = true;
    }
    return result;
}



        }





