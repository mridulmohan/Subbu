package commonpagelocators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import java.util.List;

public class  Projects_New{ 
    private static WebElement element = null;
    
    
   
  public static WebElement prname(WebDriver driver){ 
	  element = driver.findElement(By.id("project"));
    return element; 
    }
  
   
  public static WebElement typ(WebDriver driver){ 
	  element = driver.findElement(By.id("aa778o0oip"));
    return element; 
    }
  
    
  public static WebElement loc(WebDriver driver){ 
	  element = driver.findElement(By.id("aa778o0oiq"));
    return element; 
    }
  
   
  public static WebElement relat(WebDriver driver){ 
	  element = driver.findElement(By.id("aa778o0oid"));
    return element; 
    }
  
   
  public static WebElement startdt(WebDriver driver){ 
	  element = driver.findElement(By.id("aa778o0oib"));
    return element; 
    }
  
  public static WebElement enddate(WebDriver driver){ 
	  element = driver.findElement(By.id("aa778o0oij"));
    return element; 
    }
  
   
  public static WebElement desc(WebDriver driver){ 
	  element = driver.findElement(By.id("aa778o0oix"));
    return element; 
    }
  
}