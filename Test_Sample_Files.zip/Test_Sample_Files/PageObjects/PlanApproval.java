package commonpagelocators;
 
    import java.util.concurrent.TimeUnit;
	import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class PlanApproval { 
    private static WebElement element = null;

    public static WebElement app(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='approv']"));
    	  return element;   
    	
    }	
    
    
    public static WebElement reject(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='deny']"));
    	  return element;   
    	
    }	

 
    public static WebElement rejrson(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='rjreason']"));
    	  return element;   
    	
    }	

}
