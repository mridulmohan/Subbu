package commonpageLocators;
 
    import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class  HomePage{ 
    private static WebElement element = null;
    

    
  public static WebElement Account(WebDriver driver){ 
	  element = driver.findElement(By.id("SI938hhfjf"));
    return element; 
    }

   
public static WebElement Contacts(WebDriver driver){ 
    element = driver.findElement(By.id("SI938hhfjj"));
    return element; 
    }


public static WebElement Leads(WebDriver driver){ 
    element = driver.findElement(By.id("SI938hhfjk"));
    return element; 
    }


public static WebElement Opp(WebDriver driver){ 
  element = driver.findElement(By.id("SI938hhfjl"));
  return element; 
  }


}