package commonpagelocators;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
 
public class Sales_plan{ 
    private static WebElement element = null;
    
    
    public static WebElement plnnam(WebDriver driver){ 
    	  element = driver.findElement(By.id("newplan"));
    	  return element;    	  
    }
   
    public static WebElement target(WebDriver driver){ 
    	  element = driver.findElement(By.id
("hd56o0iip45d"));
    	  return element;     
    }
     
    public static WebElement pltarg(WebDriver driver){ 
    	  element = driver.findElement(By.id("hd56o0iip45e"));
    	  return element;     
    }
    
 
    public static WebElement cont(WebDriver driver){ 
    	  element = driver.findElement(By.id("hd56o0iip45f"));
    	  return element;     
    }  
    
    
    public static WebElement currency(WebDriver driver){ 
    	  element = driver.findElement(By.id("hd56o0iip45g"));
    	  return element;     
    }  
   
    public static WebElement reve(WebDriver driver){ 
  	  element = driver.findElement(By.id("hd56o0iip45h"));
  	  return element;     
  }  
      
    //SF portal_Sales plan Comments//    
    public static WebElement comments(WebDriver driver){ 
  	  element = driver.findElement(By.id("hd56o0iip45dj"));
  	  return element;     
  } 
    
  
    
    
    
}