package commonpagelocators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class  LeadsCreate{ 
    private static WebElement element = null;

    
    
  public static WebElement fname(WebDriver driver){ 
	  element = driver.findElement(By.id("leadfname"));
    return element; 
    }
  
   
  public static WebElement lname(WebDriver driver){ 
	  element = driver.findElement(By.id("leadlname"));
    return element; 
    }
  
    
  public static WebElement mob(WebDriver driver){ 
	  element = driver.findElement(By.id("ldmobile"));
    return element; 
    } 
  
    
  public static WebElement phone(WebDriver driver){ 
	  element = driver.findElement(By.id("ldphone"));
    return element; 
    } 
  
    
  public static WebElement loc(WebDriver driver){ 
	  element = driver.findElement(By.id("hd556kilkm90"));
    return element; 
    } 
    
   
  public static WebElement email(WebDriver driver){ 
	  element = driver.findElement(By.id("ldmail"));
    return element; 
    } 
  
    
  public static WebElement lcmpny(WebDriver driver){ 
	  element = driver.findElement(By.id("ldcomp"));
    return element; 
    } 
  
   
  public static WebElement mkdel(WebDriver driver){ 
	  element = driver.findElement(By.id("00BN788dddfc"));
    return element; 
    } 
  
  
  
}