 package commonpageLocators;
 
import org.openqa.selenium.*; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement;
 
public class LoginPage {
 
        private static WebElement element = null;
 
 
    public static WebElement loginusername(WebDriver driver){ 
         element = driver.findElement(By.id("name")); 
         return element; 
         }
 

     public static WebElement Password(WebDriver driver){ 
         element = driver.findElement(By.id("pwd")); 
         return element; 
         }
 

     public static WebElement Log_in(WebDriver driver){ 
         element = driver.findElement(By.id("log11")); 
         return element; 
         }
     
 