package commonpagelocators;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
 
public class Salestarget { 
    private static WebElement element = null;
    
  
    public static WebElement trgtname(WebDriver driver){ 
    	  element = driver.findElement(By.id("targname"));
    	  return element;    	  
    }
    
  
    public static WebElement trgamt(WebDriver driver){ 
    	  element = driver.findElement(By.id("d56o0opi89s"));
    	  return element;     
    }
    
   
    public static WebElement trgroll(WebDriver driver){ 
    	  element = driver.findElement(By.id("d56o0opi89t"));
    	  return element;     
    }
    
  
    public static WebElement sltcfy(WebDriver driver){ 
    	  element = driver.findElement(By.id("d56o0opi89u"));
    	  return element;     
    }  
    
   
    public static WebElement gcncy(WebDriver driver){ 
    	  element = driver.findElement(By.id("d56o0opi89v"));
    	  return element;     
    }  
        
    
    
    
}