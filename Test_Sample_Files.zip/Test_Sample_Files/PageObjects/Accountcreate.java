package commonpagelocators;
 
    import java.util.concurrent.TimeUnit;
	import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
    
    
public class Accountcreate{ 
    private static WebElement element = null;
    
       
    public static WebElement actname(WebDriver driver){ 
    	  element = driver.findElement(By.id("accen"));
    	  return element;    	  
    }	
    
    
    public static WebElement actgrp(WebDriver driver){ 
    	  element = driver.findElement(By.id("oi6672hheue"));
    	  return element;    
    }	
    
    
    public static WebElement loc(WebDriver driver){ 
    	  element = driver.findElement(By.id("oi6672hheud"));
    	  return element;    
    }
  
    public static WebElement actst(WebDriver driver){ 
    	  element = driver.findElement(By.id("oi6672hheuh"));
    	  return element;    
    }  
    
   
    public static WebElement actwsite(WebDriver driver){ 
    	  element = driver.findElement(By.id("acweb"));
    	  return element;    
    }
    
   
    public static WebElement actvatnm(WebDriver driver){ 
    	  element = driver.findElement(By.id("acvat"));
    	  return element;    
    }  
    
   
    public static WebElement actprimphno(WebDriver driver){ 
    	  element = driver.findElement(By.id("pph12"));
    	  return element;    
    }  
    
 
     
  
    public static WebElement acttypp(WebDriver driver){ 
    	  element = driver.findElement(By.id("oi6672hheuv"));
    	  return element;    
    }   
       
   
    public static WebElement parenac(WebDriver driver){ 
    	  element = driver.findElement(By.id("oi6672hheub"));
    	  return element;    
    }     
    
  
  


     
    