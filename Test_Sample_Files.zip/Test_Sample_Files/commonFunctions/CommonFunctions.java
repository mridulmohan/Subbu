package com.commonpages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class CommonFunctions {
	

public  WebDriver driver = null;	
	    
public static WebDriver browser(String browser) throws Exception 
{

System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
if(browser.equalsIgnoreCase("firefox"))
{	
WebDriver driver = new FirefoxDriver(); 
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
return driver;
}
else if(browser.equalsIgnoreCase("chrome"))
{
System.setProperty("webdriver.chrome.driver","D://chromedriver.exe");
WebDriver driver = new ChromeDriver();
return driver;
}
else{
    throw new Exception("Browser is not correct");
    }
}
	
public static void login(WebDriver dw,String url,String username,String password) throws Exception //Login invoke
	{

dw.get(url);	      														  //URL//
Login.UserName(dw).sendKeys(username);   	
Login.Password(dw).sendKeys(password);        			
Login.LogIn(dw).click();
Thread.sleep(7000);
	}


public static void Save(WebDriver dw) throws Exception		
	{ 
WebDriverWait wait = new WebDriverWait(dw, 10);
WebElement Save=Account.fnd_savebtn(dw);
Save.click();
	}


public static void Edit(WebDriver dw) throws Exception		
	{ 

System.out.println("Sample");
WebElement Edit=Edit.fnd_editbtn(dw);
Edit.click();

	}


}

public static void captureScreenShot(WebDriver ldriver,String path) throws Exception		//Screenshot Capture
	{        	 
File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
	try {
		Thread.sleep(2000);   
		FileUtils.copyFile(src, new File(path+System.currentTimeMillis()+".png"));
	    }	 
	catch (IOException e)	 
		{	 
	System.out.println(e.getMessage());	 
		}         
	}


			   


}
