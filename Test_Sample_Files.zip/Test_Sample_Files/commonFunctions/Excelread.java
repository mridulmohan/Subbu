package com.commonpages;

import java.io.File;
import java.io.IOException;
import jxl.Workbook;
import jxl.read.biff.BiffException;

/*
 * READ EXCEL DATA FOR PARAMETERISED INPUTS
  */

public class Excelread {
	File src=null;
	
	
    public static String[] readsheet(int sheetno,String path) throws BiffException, IOException
	{ 	
    	File src=new File(path);         
        Workbook wb=Workbook.getWorkbook(src);
                String[] data1 = new String[100];
                int data1qty=wb.getSheet(sheetno).getRows();
                //System.out.println("the row count is " +  wb.getSheet(0).getRows());               
                for(int i=0;i<data1qty;i++)
                {                       
                       data1[i] = wb.getSheet(sheetno).getCell(1,i).getContents();                                              
                }
                return data1;
	}
}

	